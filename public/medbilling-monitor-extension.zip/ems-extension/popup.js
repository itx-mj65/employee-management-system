const EMS_URL = 'https://ems-xi-beige.vercel.app';

// ── Init ──
async function init() {
  const data = await chrome.storage.local.get(['token', 'userName', 'userDept', 'userRole', 'isCheckedIn', 'lastCapture', 'captureCount']);

  if (!data.token) {
    showScreen('login');
    return;
  }

  showScreen('dashboard');
  updateDashboard(data);
}

function showScreen(screen) {
  document.getElementById('login-screen').style.display = screen === 'login' ? 'block' : 'none';
  document.getElementById('dashboard-screen').style.display = screen === 'dashboard' ? 'block' : 'none';
}

function updateDashboard(data) {
  // User info
  const name = data.userName || 'Employee';
  document.getElementById('user-name').textContent = name;
  document.getElementById('user-dept').textContent = data.userDept || '—';
  document.getElementById('user-avatar').textContent = name.charAt(0).toUpperCase();

  // Status
  const isIn = data.isCheckedIn;
  const dot = document.getElementById('status-dot');
  dot.className = 'status-dot ' + (isIn ? 'active' : 'off');
  document.getElementById('status-text').textContent = isIn ? 'Monitoring Active' : 'Monitoring Paused';
  document.getElementById('status-sub').textContent = isIn ? '🟢 Live' : '⏸️ Check in first';

  // Check-in badge
  const badge = document.getElementById('checkin-badge');
  if (isIn) {
    badge.className = 'checkin-status active';
    badge.textContent = '✅ Checked In — Screenshots Active';
  } else {
    badge.className = 'checkin-status inactive';
    badge.textContent = '⏸️ Not Checked In — Monitoring Paused';
  }

  // Stats
  document.getElementById('capture-count').textContent = data.captureCount || 0;

  // Last capture
  if (data.lastCapture) {
    const d = new Date(data.lastCapture);
    document.getElementById('last-capture').textContent = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  }
}

// ── Login ──
async function login() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const btn = document.getElementById('login-btn');
  const err = document.getElementById('login-error');

  if (!email || !password) { showError('Enter email and password'); return; }

  btn.disabled = true;
  btn.textContent = 'Signing in...';
  err.style.display = 'none';

  try {
    const res = await fetch(`${EMS_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!res.ok || !data.user) {
      showError(data.error || 'Login failed'); btn.disabled = false; btn.textContent = 'Sign In'; return;
    }

    // Only employees, TL, managers can use extension
    const allowedRoles = ['employee', 'team-lead', 'manager'];
    if (!allowedRoles.includes(data.user.role)) {
      showError('Admin accounts do not need monitoring'); btn.disabled = false; btn.textContent = 'Sign In'; return;
    }

    // Get cookie token from response headers (set by server)
    // Store user info
    await chrome.storage.local.set({
      token: data.token || 'session',
      userId: data.user._id,
      userName: data.user.name,
      userDept: data.user.department,
      userRole: data.user.role,
      isCheckedIn: false,
      captureCount: 0,
    });

    // Notify background
    chrome.runtime.sendMessage({ type: 'LOGIN_SUCCESS', token: data.token, userId: data.user._id });

    showScreen('dashboard');
    init();
  } catch (e) {
    showError('Connection error — check internet'); btn.disabled = false; btn.textContent = 'Sign In';
  }
}

function showError(msg) {
  const err = document.getElementById('login-error');
  err.textContent = msg;
  err.style.display = 'block';
}

// ── Logout ──
async function logout() {
  await chrome.storage.local.clear();
  chrome.runtime.sendMessage({ type: 'LOGOUT' });
  showScreen('login');
}

// ── Manual capture ──
async function captureNow() {
  const btn = document.querySelector('.btn-capture');
  btn.textContent = 'Capturing...';
  btn.disabled = true;
  chrome.runtime.sendMessage({ type: 'CAPTURE_NOW' }, () => {
    btn.textContent = '✅ Done!';
    setTimeout(() => { btn.textContent = 'Capture Now'; btn.disabled = false; }, 1500);
  });
}

// Listen for storage changes to update UI live
chrome.storage.onChanged.addListener((changes) => {
  if (changes.isCheckedIn || changes.lastCapture || changes.captureCount) {
    chrome.storage.local.get(['token', 'userName', 'userDept', 'userRole', 'isCheckedIn', 'lastCapture', 'captureCount'], updateDashboard);
  }
});

// ── Start ──
init();
