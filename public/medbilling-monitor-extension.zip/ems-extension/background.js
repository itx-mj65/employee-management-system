const EMS_URL = 'https://ems-xi-beige.vercel.app';
const ALARM_NAME = 'screenshot-alarm';

// ── Get random interval (8-15 minutes) ──
function randomMinutes() {
  return 8 + Math.random() * 7; // 8-15 min
}

// ── Get stored auth token ──
async function getToken() {
  const data = await chrome.storage.local.get(['token', 'userId', 'isCheckedIn']);
  return data;
}

// ── Take screenshot + upload ──
async function takeScreenshot() {
  const { token, userId, isCheckedIn } = await getToken();

  // Only capture if user is checked in
  if (!token || !isCheckedIn) {
    console.log('[Monitor] Skipping — not checked in or no token');
    scheduleNext();
    return;
  }

  try {
    // Get active tab
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab) { scheduleNext(); return; }

    // Capture screenshot
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'jpeg',
      quality: 60,
    });

    // Upload to EMS
    const res = await fetch(`${EMS_URL}/api/screenshots`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Cookie': `token=${token}`,
      },
      credentials: 'include',
      body: JSON.stringify({
        imageData: dataUrl,
        takenAt: new Date().toISOString(),
      }),
    });

    const data = await res.json();
    if (res.ok) {
      console.log('[Monitor] Screenshot uploaded:', data.screenshot?._id);
      // Update last capture time
      await chrome.storage.local.set({ lastCapture: new Date().toISOString(), status: 'active' });
    } else {
      console.error('[Monitor] Upload failed:', data.error);
      if (res.status === 401) {
        // Token expired — clear and show re-login
        await chrome.storage.local.remove(['token', 'userId', 'isCheckedIn']);
        chrome.action.setBadgeText({ text: '!' });
        chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
      }
    }
  } catch (err) {
    console.error('[Monitor] Error:', err.message);
  }

  scheduleNext();
}

// ── Schedule next random alarm ──
function scheduleNext() {
  const minutes = randomMinutes();
  chrome.alarms.create(ALARM_NAME, { delayInMinutes: minutes });
  console.log(`[Monitor] Next screenshot in ${minutes.toFixed(1)} min`);
}

// ── Alarm fires ──
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) takeScreenshot();
});

// ── Sync check-in status with EMS every 2 min ──
chrome.alarms.create('sync-status', { periodInMinutes: 2 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sync-status') return;

  const { token } = await getToken();
  if (!token) return;

  try {
    const res = await fetch(`${EMS_URL}/api/attendance/today?personal=true`, {
      headers: { 'Cookie': `token=${token}` },
      credentials: 'include',
    });
    const data = await res.json();
    const att = data.attendance;
    const isIn = !!(att?.checkIn && !att?.checkOut);

    await chrome.storage.local.set({ isCheckedIn: isIn });

    // Update badge
    if (isIn) {
      chrome.action.setBadgeText({ text: 'ON' });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    } else {
      chrome.action.setBadgeText({ text: 'OFF' });
      chrome.action.setBadgeBackgroundColor({ color: '#94a3b8' });
    }
  } catch (e) {
    console.error('[Monitor] Sync error:', e.message);
  }
});

// ── On install/startup — check login + start ──
chrome.runtime.onInstalled.addListener(async () => {
  console.log('[Monitor] Extension installed');
  scheduleNext();
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[Monitor] Browser started');
  scheduleNext();
});

// ── Message from popup (login/logout) ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'LOGIN_SUCCESS') {
    chrome.storage.local.set({ token: msg.token, userId: msg.userId });
    chrome.action.setBadgeText({ text: 'ON' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    scheduleNext();
    sendResponse({ ok: true });
  }
  if (msg.type === 'LOGOUT') {
    chrome.storage.local.remove(['token', 'userId', 'isCheckedIn', 'lastCapture']);
    chrome.alarms.clear(ALARM_NAME);
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ ok: true });
  }
  return true;
});
